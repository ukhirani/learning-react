const CurrentColor = ({ color }) => {
  return <div class="current-color">Color - {color}</div>;
};

export default CurrentColor;
